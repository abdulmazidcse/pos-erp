<?php


namespace App\DataGrid;

use Yazan\DataTable\DataGrid;

class SalesGrid extends DataGrid
{

    public $model = "App\Models\Sale";

}